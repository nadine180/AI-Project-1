
public class EndGameState extends State{	
	
	String state;
	boolean snap;
	String actions="";
	

	public EndGameState(String state,String actions)
	{
		this.state= state;
		this.snap=false;
		this.actions=actions;
	}
	public EndGameState(String state,boolean snap,String actions)
	{
		this.state= state;
		this.snap=snap;
		this.actions=actions;
	}
	
	
	
}
