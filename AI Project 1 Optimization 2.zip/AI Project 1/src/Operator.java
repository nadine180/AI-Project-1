
public enum Operator {
	UP,DOWN,LEFT,RIGHT,KILL;
 }
