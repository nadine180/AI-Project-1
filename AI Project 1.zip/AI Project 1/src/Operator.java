
public enum Operator {
	UP,DOWN,LEFT,RIGHT,COLLECT,KILL,SNAP;
 }
