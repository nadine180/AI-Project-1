import java.awt.Point;
import java.util.ArrayList;

public class End_Game extends Problem {
	
	State initState;
	Operator [] operators;
	
	
	public End_Game()
	{
		
	}
	
	
	@Override
	public int pathCost() {
		
		
		
		return 0;
	}

	@Override
	public boolean goalTest(State state1) {

		EndGameState state = (EndGameState) state1;
		
		if(state.damage >= 100 && state.ironman.x == state.thanos.x && state.ironman.y == state.thanos.y && state.stones.isEmpty())
			return true;
		
		
		return false;
	}

	@Override
	public State transitionFun(Operator operator, State oldState) {
		// TODO Auto-generated method stub
		
		
		EndGameState oldEndGameState = (EndGameState) oldState;
		switch(operator)
		{
		case UP:		return UP(oldEndGameState);
		case DOWN: 		return DOWN(oldEndGameState);
		case LEFT: 		return LEFT(oldEndGameState);
		case RIGHT: 	return RIGHT(oldEndGameState);
		case KILL:  	return KILL(oldEndGameState);
		case COLLECT:	return COLLECT(oldEndGameState);
		case SNAP: break;
		default: break;
		}
		
		
		return null;
	}
	

public  EndGameState UP(EndGameState oldState)
{
	Point ironman = ((EndGameState) oldState).ironman;
	
	if(ironman.x - 1 < 0)
		return oldState;
	
	else
	{
		
		if(oldState.thanos.x == ironman.x-1 && oldState.thanos.y == ironman.y)
			return oldState;
		
		for(int i = 0; i < oldState.warriors.size();i++)
		{
			int warriorX = oldState.warriors.get(i).x;
			int warriorY = oldState.warriors.get(i).y;
			if(warriorX == ironman.x-1 && warriorY == ironman.y)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x -1, ironman.y);
		int damage = checkDamage(newIronman, oldState.thanos, oldState.warriors) + oldState.damage;
		
		
		
	
	return (new EndGameState(newIronman,oldState.thanos,damage,oldState.stones,oldState.warriors,oldState.gridDimensions));
}

public EndGameState DOWN (EndGameState oldState)
{
Point ironman = ((EndGameState) oldState).ironman;
	
	if(ironman.x + 1 < 0)
		return oldState;
	
	else
	{
		
		if(oldState.thanos.x == ironman.x+1 && oldState.thanos.y == ironman.y)
			return oldState;
		
		for(int i = 0; i < oldState.warriors.size();i++)
		{
			int warriorX = oldState.warriors.get(i).x;
			int warriorY = oldState.warriors.get(i).y;
			if(warriorX == ironman.x+1 && warriorY == ironman.y)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x +1, ironman.y);
		int damage = checkDamage(newIronman, oldState.thanos, oldState.warriors) + oldState.damage;
		
		
		
	
	return (new EndGameState(newIronman,oldState.thanos,damage,oldState.stones,oldState.warriors,oldState.gridDimensions));
	
}

public EndGameState LEFT(EndGameState oldState)
{
Point ironman = ((EndGameState) oldState).ironman;
	
	if(ironman.y - 1 < 0)
		return oldState;
	
	else
	{
		
		if(oldState.thanos.y == ironman.y-1 && oldState.thanos.x == ironman.x)
			return oldState;
		
		for(int i = 0; i < oldState.warriors.size();i++)
		{
			int warriorX = oldState.warriors.get(i).x;
			int warriorY = oldState.warriors.get(i).y;
			if(warriorY == ironman.y-1 && warriorX == ironman.x)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x, ironman.y-1);
		int damage = checkDamage(newIronman, oldState.thanos, oldState.warriors) + oldState.damage;
		
		
		
	
	return (new EndGameState(newIronman,oldState.thanos,damage,oldState.stones,oldState.warriors,oldState.gridDimensions));
	
}

public EndGameState RIGHT (EndGameState oldState)
{
Point ironman = ((EndGameState) oldState).ironman;
	
	if(ironman.y + 1 < 0)
		return oldState;
	
	else
	{
		
		if(oldState.thanos.y == ironman.y+1 && oldState.thanos.x == ironman.x)
			return oldState;
		
		for(int i = 0; i < oldState.warriors.size();i++)
		{
			int warriorX = oldState.warriors.get(i).x;
			int warriorY = oldState.warriors.get(i).y;
			if(warriorY == ironman.y+1 && warriorX == ironman.x)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x, ironman.y+1);
		int damage = checkDamage(newIronman, oldState.thanos, oldState.warriors) + oldState.damage;
		
		
		
	
	return (new EndGameState(newIronman,oldState.thanos,damage,oldState.stones,oldState.warriors,oldState.gridDimensions));
	
}

public EndGameState COLLECT (EndGameState oldState)
{
	
	ArrayList<Point> newStones = new ArrayList<Point>();
	for(int i = 0; i < oldState.stones.size();i++)
	{
		newStones.add(new Point(oldState.stones.get(i).x,oldState.stones.get(i).y));
	}
	Point newIronman = new Point(oldState.ironman.x,oldState.ironman.y);
	int damage = checkDamage(newIronman,oldState.thanos,oldState.warriors);
	int size = oldState.stones.size();
	int removeStone = -1;
	
	for(int i = 0; i < size;i++)
	{
		if(newIronman.x == oldState.stones.get(i).x && newIronman.y == oldState.stones.get(i).y )
		{
			damage += 3;
			removeStone = i;
		}
	}
	
	
	if(removeStone >= 0)
	{
	newStones.remove(removeStone);
	
	return new EndGameState(newIronman, oldState.thanos,damage,newStones, oldState.warriors,oldState.gridDimensions);
	}
	
	else
		return oldState;
}

public EndGameState KILL (EndGameState oldState)

{
	
	ArrayList<Point> warriors = new ArrayList<Point>();
	int size = oldState.warriors.size();
	for(int i = 0; i < size;i++)
	{
		warriors.add(new Point(oldState.warriors.get(i).x,oldState.warriors.get(i).y ));
	}
	
	int damage = 0;
	for(int i = 0; i < size;i++)
	{
		int warriorX = warriors.get(i).x;
		int warriorY = warriors.get(i).y;
		
		if(warriorX == oldState.ironman.x)
		{
			if(warriorY == oldState.ironman.y -1 || warriorY == oldState.ironman.y + 1)
			{
				damage +=2;
				warriors.remove(i);
			}
		}
		if(warriorY == oldState.ironman.y && (warriorX == oldState.ironman.x -1 || warriorX == oldState.ironman.x + 1))
		{
			damage +=2;
			warriors.remove(i);
		}
		
		
	}
	
	if(oldState.thanos.y == oldState.ironman.y && (oldState.thanos.x == oldState.ironman.x -1 || oldState.thanos.x == oldState.ironman.x+1))
		damage +=5;
	return new EndGameState(oldState.ironman, oldState.thanos, damage, oldState.stones, warriors, oldState.gridDimensions);
}


//add stuff to snap. figure out where to put the tracing back get solution
public EndGameState SNAP(EndGameState state)
{
	goalTest(state);
	
	return state;
}

public int checkDamage(Point newIronman, Point thanos, ArrayList<Point> warriors)
{
	int damage = 0;
	
	//check warriors
	for(int i = 0; i < warriors.size();i++)
	{
		int warriorX = warriors.get(i).x;
		int warriorY = warriors.get(i).y;
		
		if(warriorX == newIronman.x)
		{
			if(warriorY == newIronman.y -1 || warriorY == newIronman.y + 1)
				damage +=1;
		}
		if(warriorY == newIronman.y && (warriorX == newIronman.x -1 || warriorX == newIronman.x + 1))
			damage +=1;
	}
	
	
	//check thanos
	if(thanos.x == newIronman.x)
	{
		if(thanos.y  == newIronman.y -1 || thanos.y  == newIronman.y + 1)
			damage +=5;
	}
	
	if(thanos.y == newIronman.y && (thanos.x == newIronman.x -1 || thanos.x == newIronman.x+1))
		damage +=5;
	return damage;
}

}
