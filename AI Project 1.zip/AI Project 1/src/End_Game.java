
public class End_Game extends Generic_Search{

	public End_Game(Problem p, String strategy) {
		super(p,strategy);
	}

	@Override
	public boolean goalTest(State state) {
		// TODO Auto-generated method stub
		
//		State test = new State();
//		test.state = (byte) 127;
		return false;
	}

	@Override
	public int pathCost() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public Search_Node transitionFun() {
		return null;
	}


}
