import java.awt.Point;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class End_Game extends Problem {
	
	State initState;
	Operator [] operators = {Operator.DOWN,Operator.UP,Operator.LEFT,Operator.RIGHT,Operator.COLLECT,Operator.KILL,Operator.SNAP};
	
	
	
	public End_Game(EndGameState initState,Operator[] operators)
	{

		super(initState,operators);
	
		this.initState = initState;
		
		
		
	}
	
	
	@Override
	public int pathCost() {
		
		
		
		return 0;
	}

	@Override
	public boolean goalTest(State n) {

		String s = ((EndGameState)n).state;
		
		int damage= getDamage(s);
		Point ironman= getIronman(s);
		Point thanos= getThanos(s);
		Point gridDimension= getDimensions(s);
		ArrayList<Point> stones = getStones(s);
		ArrayList<Point> warriors= getWarriors(s);

		
		if(damage < 100 ){
			
			if(stones.size()==0){
				
				System.out.println("stones");
			if(ironman.x == thanos.x){
				System.out.println("thanx");
				if( ironman.y == thanos.y ){
					System.out.println("thany");
				
						
						
			return true;
		
		}}}}
		return false;
		
	}

	@Override
	public State transitionFun(Operator operator, State oldState) {
	
		
		EndGameState oldEndGameState = (EndGameState) oldState;
	//	System.out.println(oldEndGameState.ironman);
		switch(operator)
		{
		case UP:		return UP(oldEndGameState);
		case DOWN: 		return DOWN(oldEndGameState);
		case LEFT: 		return LEFT(oldEndGameState);
		case RIGHT: 	return RIGHT(oldEndGameState);
		case KILL:  	return KILL(oldEndGameState);
		case COLLECT:	return COLLECT(oldEndGameState);
		case SNAP:		return SNAP(oldEndGameState);
		default: break;
		}
		
		
		return null;
	}
	

public  EndGameState UP(EndGameState oldState)
{
	
	
	String s = oldState.state;
	//System.out.println("oldState in UP"+ oldState.state);
	int damage= getDamage(s);
	Point ironman= getIronman(s);
	Point thanos= getThanos(s);
	//Point gridDimension= getDimensions(s);
	ArrayList<Point> warriors= getWarriors(s);
	
	
	if(ironman.x - 1 < 0)
		return oldState;
	
	else
	{
		
		if(thanos.x == ironman.x-1 && thanos.y == ironman.y)
			return oldState;
		
		for(int i = 0; i < warriors.size();i++)
		{
			int warriorX = warriors.get(i).x;
			int warriorY = warriors.get(i).y;
			if(warriorX == ironman.x-1 && warriorY == ironman.y)
				return oldState;
		}
		
	}
	
		
	Point newIronman = new Point(ironman.x -1, ironman.y);
	

		int dam = checkDamage(newIronman, thanos, warriors) + damage;
		
		
		
	String newState= setDamage(dam,s);
	newState= setIronman(newState,newIronman);
	//System.out.println("New State  "+newState);
	
	return (new EndGameState(newState));
}

public EndGameState DOWN (EndGameState oldState)
{
	Point ironman = getIronman(oldState.state);
	int damage = getDamage(oldState.state);
	Point gridDimensions= getDimensions(oldState.state);
	Point thanos= getThanos(oldState.state);
	ArrayList<Point> warriors= getWarriors(oldState.state);
	
	
	
	if(ironman.x + 1 > gridDimensions.x)
		return oldState;
	
	else
	{
		
		if(thanos.x == ironman.x+1 && thanos.y == ironman.y)
			return oldState;
		
		for(int i = 0; i < warriors.size();i++)
		{
			int warriorX = warriors.get(i).x;
			int warriorY = warriors.get(i).y;
			if(warriorX == ironman.x+1 && warriorY == ironman.y)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x +1, ironman.y);
		int dam = checkDamage(newIronman, thanos, warriors) + damage;
		
		
		String newState= setDamage(dam,oldState.state);
		newState= setIronman(newState,newIronman);
		
		return (new EndGameState(newState));
	
}

public EndGameState LEFT(EndGameState oldState)
{
	Point ironman = getIronman(oldState.state);
	int damage = getDamage(oldState.state);
	Point thanos= getThanos(oldState.state);
	ArrayList<Point> warriors= getWarriors(oldState.state);
	
	
	if(ironman.y - 1 < 0)
		return oldState;
	
	else
	{
		
		if(thanos.y == ironman.y-1 && thanos.x == ironman.x)
			return oldState;
		
		for(int i = 0; i < warriors.size();i++)
		{
			int warriorX = warriors.get(i).x;
			int warriorY = warriors.get(i).y;
			if(warriorY == ironman.y-1 && warriorX == ironman.x)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x, ironman.y-1);
		int dam = checkDamage(newIronman, thanos, warriors) + damage;

		String newState= setDamage(dam,oldState.state);
		newState= setIronman(newState,newIronman);
		
		return (new EndGameState(newState));
		
		
	
	
	
}

public EndGameState RIGHT (EndGameState oldState)
{
	Point ironman = getIronman(oldState.state);
	int damage = getDamage(oldState.state);
	Point thanos= getThanos(oldState.state);
	Point gridDimensions= getDimensions(oldState.state);
	ArrayList<Point> warriors= getWarriors(oldState.state);
	
	if(ironman.y + 1 > gridDimensions.y)
		return oldState;
	
	else
	{
		
		if(thanos.y == ironman.y+1 && thanos.x == ironman.x)
			return oldState;
		
		for(int i = 0; i < warriors.size();i++)
		{
			int warriorX = warriors.get(i).x;
			int warriorY = warriors.get(i).y;
			if(warriorY == ironman.y+1 && warriorX == ironman.x)
				return oldState;
		}
		
	}
	
		Point newIronman = new Point(ironman.x, ironman.y+1);
		int dam = checkDamage(newIronman, thanos, warriors) + damage;

		String newState= setDamage(dam,oldState.state);
		newState= setIronman(newState,newIronman);
		
		return (new EndGameState(newState));
	
}

public EndGameState COLLECT (EndGameState oldState)
{
	ArrayList<Point> stones = getStones(oldState.state);
	Point ironman = getIronman(oldState.state);
	Point thanos= getThanos(oldState.state);
	ArrayList<Point> warriors = getWarriors(oldState.state);
	
	
	
	
	ArrayList<Point> newStones = new ArrayList<Point>();
	for(int i = 0; i < stones.size();i++)
	{
		newStones.add(new Point(stones.get(i).x,stones.get(i).y));
	}
	Point newIronman = new Point(ironman.x,ironman.y);
	int dam = checkDamage(newIronman,thanos,warriors);
	int removeStone = -1;
	
	for(int i = 0; i < newStones.size();i++)
	{
		if(newIronman.x == newStones.get(i).x && newIronman.y == newStones.get(i).y )
		{
			dam += 3;
			removeStone = i;
			newStones.remove(i);
			i--;
		}
	}
	
	
	if(removeStone >= 0)
	{
		String newState= setDamage(dam,oldState.state);
		newState= setIronman(newState,newIronman);
		newState= setStones(newState, newStones);
		
		return (new EndGameState(newState));
		
	}
	
	else
		return oldState;
}

public EndGameState KILL (EndGameState oldState)

{
	
	Point ironman = getIronman(oldState.state);
	Point thanos= getThanos(oldState.state);
	ArrayList<Point> warriors = getWarriors(oldState.state);
	

	int damage = getDamage(oldState.state);
	if(warriors.size()>0){
	for(int i = 0; i <warriors.size();i++)
	{
		int warriorX = warriors.get(i).x;
		int warriorY = warriors.get(i).y;
		
		if(warriorX == ironman.x)
		{
			if(warriorY == ironman.y -1 || warriorY == ironman.y + 1)
			{
				damage +=2;
				warriors.remove(i);
				i--;
			}
		}
		if(warriorY == ironman.y && (warriorX == ironman.x -1 || warriorX == ironman.x + 1))
		{
			damage +=2;
			warriors.remove(i);
			i--;
		}
		
		
	}}
	
	if(thanos.y == ironman.y && (thanos.x == ironman.x -1 || thanos.x == ironman.x+1))
		damage +=5;
	
	
	String newState= setDamage(damage,oldState.state);
	newState= setStones(newState, warriors);
	
	return (new EndGameState(newState));
}

//add stuff to snap. figure out where to put the tracing back get solution
public EndGameState SNAP(EndGameState oldState)
{
	Point ironman = getIronman(oldState.state);
	Point thanos= getThanos(oldState.state);
	//ArrayList<Point> warriors = getWarriors(oldState.state);
	ArrayList<Point> stones= getStones(oldState.state);
	int damage = getDamage(oldState.state);
	
	
	if(stones.size()!=0 ||( ironman.x == thanos.x && ironman.y == thanos.y)||damage>=100)
		return oldState;
	else
		return null;
		
	

}

public int checkDamage(Point newIronman, Point thanos, ArrayList<Point> warriors)

{
	int damage = 0;
	
	//check warriors
	for(int i = 0; i < warriors.size();i++)
	{
		int warriorX = warriors.get(i).x;
		int warriorY = warriors.get(i).y;
		
		if(warriorX == newIronman.x)
		{
			if(warriorY == newIronman.y -1 || warriorY == newIronman.y + 1)
				damage +=1;
		}
		if(warriorY == newIronman.y && (warriorX == newIronman.x -1 || warriorX == newIronman.x + 1))
			damage +=1;
	}
	
	
	//check thanos
	if(thanos.x == newIronman.x)
	{
		if(thanos.y  == newIronman.y -1 || thanos.y  == newIronman.y + 1)
			damage +=5;
	}
	
	if(thanos.y == newIronman.y && (thanos.x == newIronman.x -1 || thanos.x == newIronman.x+1))
		damage +=5;
	return damage;
}

public int getDamage(String state){
StringTokenizer st = new StringTokenizer(state,";");
return Integer.parseInt(st.nextToken());
}

public String setDamage(int damage,String state){
	StringTokenizer st= new StringTokenizer (state,";");
	st.nextToken();
	String newState= damage+"";
	while(st.hasMoreElements()){
		newState+=";"+st.nextToken();
	}
	
	return newState;
	
}

public Point getDimensions(String state){
StringTokenizer st = new StringTokenizer(state,";");
st.nextToken();
StringTokenizer sst= new StringTokenizer(st.nextToken(),",");
int x= Integer.parseInt(sst.nextToken());
int y = Integer.parseInt(sst.nextToken());
return new Point(x,y);
}

public Point getIronman(String state){

	StringTokenizer st = new StringTokenizer(state,";");
	st.nextToken();
	st.nextToken();
	StringTokenizer sst= new StringTokenizer(st.nextToken(),",");
	int x= Integer.parseInt(sst.nextToken());
	int y = Integer.parseInt(sst.nextToken());
	return new Point(x,y);
	
}

public String setIronman(String state, Point im){
	StringTokenizer st = new StringTokenizer(state,";");
	String newState= st.nextToken()+";"+st.nextToken()+";";
	st.nextToken();
	newState +=im.x+","+im.y;
	while(st.hasMoreElements()){
		newState+=";"+st.nextToken();
	}
	return newState;
	
	
}

public Point getThanos(String state){
	StringTokenizer st = new StringTokenizer(state,";");
	st.nextToken();//damage
	st.nextToken();//gridDime
	st.nextToken();//ironman
	StringTokenizer sst= new StringTokenizer(st.nextToken(),",");
	String next= sst.nextToken();
	if(!next.equals("s")&& !next.equals("w")){
	int x= Integer.parseInt(next);
	int y = Integer.parseInt(sst.nextToken());
	return new Point(x,y);
	}
	else return null;
}

public ArrayList<Point> getStones(String state){
	StringTokenizer st = new StringTokenizer(state,";");
	st.nextToken();//damage
	st.nextToken();//dimensions
	st.nextToken();//ironman
	st.nextToken();//thanos
	String stoneString= st.nextToken();
	ArrayList<Point> stones= new ArrayList<Point>();
	StringTokenizer sst= new StringTokenizer(stoneString,",");
	String b= sst.nextToken();
	if(!b.equals("s")){
		return stones;
	}
	while(sst.hasMoreTokens()){
		int x= Integer.parseInt(sst.nextToken());
		int y = Integer.parseInt(sst.nextToken());
		Point p = new Point(x,y);
		stones.add(p);
	}
	
	
	
	return stones;
}

//the array list is ready i just transform it to a string
public String setStones(String state,ArrayList<Point> stones)
{
	String stoneString = "s";
	for(int i = 0; i < stones.size();i++)
	{
		stoneString += "," + stones.get(i).x + "," + stones.get(i).y;
	}
	if(stoneString.equals("s")){
		stoneString="";
	}
	
	StringTokenizer st = new StringTokenizer(state,";");
	String grid = st.nextToken();
	String ironman = st.nextToken();
	String thanos = st.nextToken();
	st.nextToken();
	String restofstate = "";
	
	if(st.hasMoreTokens())
		restofstate += st.nextToken();
	
	
	if(!restofstate.equals("")){
		if(!stoneString.isEmpty())
			state =  grid + ";" + ironman + ";" + thanos+ ";" + stoneString +";"+restofstate;
		else
		state=  grid + ";" + ironman + ";" + thanos +";"+restofstate;
	}
	
	else{
		if(!stoneString.isEmpty())
	state =  grid + ";" + ironman + ";" + thanos+ ";" + stoneString;
		else{
			state =  grid + ";" + ironman + ";" + thanos;
		}
	}
	return state;
}

public ArrayList<Point> getWarriors(String state){
	String warriorString="";
	StringTokenizer st = new StringTokenizer(state,";");
	st.nextToken();//damage
	st.nextToken();//dimensions
	st.nextToken();//ironman
	st.nextToken();//thanos
	if(st.hasMoreElements()){
	String s= st.nextToken();//stones
	StringTokenizer sst= new StringTokenizer(s,",");
	String b= sst.nextToken();
	if(b.equals("w")){
		warriorString= s;
	}
	}
	if(st.hasMoreElements()){
	warriorString = st.nextToken();}
	ArrayList<Point> warriors= new ArrayList<Point>();
	StringTokenizer sst= new StringTokenizer(warriorString,",");
	String b= sst.nextToken();
	if(!b.equals("w")){
		return warriors;
	}
	while(sst.hasMoreTokens()){
		int x= Integer.parseInt(sst.nextToken());
		int y = Integer.parseInt(sst.nextToken());
		Point p = new Point(x,y);
		warriors.add(p);
	}
	
	
	
	return warriors;
}
public String setWarriors(String state,ArrayList<Point> warriors)
{
	String warriorsString = "w";
	for(int i = 0; i < warriors.size();i++)
	{
		warriorsString += "," + warriors.get(i).x + "," + warriors.get(i).y;
	}
	if(warriorsString.equals("w")){
		warriorsString="";
	}
	
	StringTokenizer st = new StringTokenizer(state,";");
	String grid = st.nextToken();
	String ironman = st.nextToken();
	String thanos = st.nextToken();
	String stones=st.nextToken();
	StringTokenizer sst= new StringTokenizer(stones,",");
	String b= sst.nextToken();
	if (b.equals("s")&& st.hasMoreElements()){
		st.nextToken();
	}
	
	
	
	if(b.equals("s"))
	state =  grid + ";" + ironman + ";" + thanos+ ";" + stones +";"+warriorsString;
	
	else
	state =  grid + ";" + ironman + ";" + thanos+ ";" + warriorsString;
	
	return state;
}




}
