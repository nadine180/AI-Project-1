
public class End_Game extends Problem {
	
	State initState;
	Operator [] operators;
	
	
	public End_Game()
	{
		
	}
	
	
	@Override
	public int pathCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean goalTest(Search_Node node) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public State transitionFun(Operator operator, State oldState) {
		// TODO Auto-generated method stub
		return null;
	}

}
