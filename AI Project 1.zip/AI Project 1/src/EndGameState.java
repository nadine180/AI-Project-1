import java.awt.Point;
import java.util.ArrayList;

public class EndGameState extends State{
	

	//damage concat grid
	String state;
	boolean snap;
	

	public EndGameState(String state)
	{
		this.state= state;
		this.snap=false;
	}
	public EndGameState(String state,boolean snap)
	{
		this.state= state;
		this.snap=snap;
	}
	
	
	
}
