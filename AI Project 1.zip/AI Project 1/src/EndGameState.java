
public class EndGameState extends State{	
	
	String state;
	boolean snap;
	

	public EndGameState(String state)
	{
		this.state= state;
		this.snap=false;
	}
	public EndGameState(String state,boolean snap)
	{
		this.state= state;
		this.snap=snap;
	}
	
	
	
}
