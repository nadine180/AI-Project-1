import java.awt.Point;
import java.util.ArrayList;

public class EndGameState extends State{
	ArrayList<Point> stones;
	ArrayList<Point> warriors;
	Point ironman;
	Point thanos;
	int damage;
	

	public EndGameState(Point ironman,Point thanos, int damage, ArrayList<Point> stones, ArrayList<Point> warriors)
	{
		this.ironman = ironman;
		this.thanos = thanos;
		this.damage = damage;
		this.stones = stones;
		this.warriors = warriors;
	}
	
	
}
