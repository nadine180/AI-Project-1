import java.awt.Point;
import java.util.ArrayList;

public class EndGameState extends State{
	

	//damage concat grid
	String state;
	
	

	public EndGameState(String state)
	{
		this.state= state;
	}
	
	
	
}
