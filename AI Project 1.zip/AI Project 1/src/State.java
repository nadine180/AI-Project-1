
public class State {
	
	Object state;
}
