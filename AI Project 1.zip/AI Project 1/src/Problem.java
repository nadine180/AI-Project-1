import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;


public abstract class Problem {
	State initState;
	Operator [] operators;    
	
	
public Problem(State initState, Operator[] operators){
	this.initState=initState;
	this.operators=operators;
}
	
public abstract int pathCost();

public abstract boolean goalTest(State n);

public abstract State transitionFun(Operator operator, State oldState);
public String General_Search(Problem p, String QuinFun)

{	

	Search_Node root = new Search_Node(p.initState);
	Queue<Search_Node> nodes = new LinkedList<Search_Node>();
	nodes.add(root);
	HashMap<String, State> hm = new HashMap<String, State>();
	hm.put(((EndGameState)root.state).state,root.state);
	int numNodes=0;

	while(true)
	{
	
		Search_Node node = null;
		//System.out.println(nodes.size());
		if(nodes.size() == 0) { System.out.println("Failed");return null;}
		
		else
		{
			node = nodes.poll();
			numNodes+=1;
			//System.out.println(node.operator+" "+((EndGameState)node.state).state);
				
			if(p.goalTest(node.state)){
				//System.out.println("2ay7aga");
				StringTokenizer st= new StringTokenizer(((EndGameState)node.state).state,";");
				String s=";"+ (st.nextToken()) +";"+numNodes;
				int depth=node.depth;
				for(int i=depth; i>0;i--){
					
					s=", "+node.operator+s;
					node=node.parent;
				}
				System.out.println(s);
				return s;
		}}
		ArrayList <Search_Node> expandedNodes= new ArrayList<Search_Node>();
		for(int i = 0; i <p.operators.length;i++)
		{	
	
			State newState =transitionFun(p.operators[i], node.state );
			
			
			if(hm.get(((EndGameState)newState).state)==null){
				
				Search_Node n= new Search_Node(newState, node, pathCost(), node.depth+1,p.operators[i]);
				
				expandedNodes.add(n);
				hm.put(((EndGameState)newState).state, newState);
			}
			}
		
		
		switch(QuinFun) 
		{
			case "BF": nodes = BF(nodes,expandedNodes);	break;
			case "DF": nodes = DF(nodes,expandedNodes); break;
			case "ID": nodes = ID(nodes,expandedNodes); break;
			case "UC": nodes = UC(nodes,expandedNodes); break;
			case "GRi":nodes = GRi(nodes,expandedNodes);break;
			case "ASi":nodes = ASi(nodes,expandedNodes);break;
			default: 	break;
		}
		
		
		
		
	}
		
}

public Queue<Search_Node> BF(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	
	for(int i=0; i<expandedNodes.size();i++) {
		q.add(expandedNodes.get(i));	
	}

	return q;
	
}

public Queue<Search_Node> DF(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	
	Queue<Search_Node> temp = new LinkedList<Search_Node>();
	
	for(int i=0; i<expandedNodes.size();i++) {
		temp.add(expandedNodes.get(i));	
	}
	while(!q.isEmpty()){
		temp.add(q.poll());
	}
	
	
	return temp;
	
}

public Queue<Search_Node> ID(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{


return null;
}

public Queue<Search_Node> UC(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	return null;
}

public Queue<Search_Node> GRi(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	return null;

}
public Queue<Search_Node> ASi(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	return null;

}


}