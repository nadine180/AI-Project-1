import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;


public abstract class Problem {
	State initState;
	Operator [] operators;    
	
	
public abstract int pathCost();

public abstract boolean goalTest(State state);

public abstract State transitionFun(Operator operator, State oldState);
public Search_Node General_Search(Problem p, String QuinFun)
{
	Search_Node root = new Search_Node(p.initState);
	Queue<Search_Node> nodes = new LinkedList<Search_Node>();
	nodes.add(root);
	
	while(true)
	{
		Search_Node node = null;
		if(nodes.size() == 0) return null;
		
		else
		{
			node = nodes.poll();
			if(p.goalTest(node.state))
				return node;
		}
		ArrayList <Search_Node> expandedNodes= new ArrayList<Search_Node>();
		for(int i = 0; i <p.operators.length;i++)
		{
			State newState =transitionFun(p.operators[i], node.state );
			expandedNodes.add(new Search_Node(newState, node, pathCost(), node.depth+1,p.operators[i]));
		}
		
		switch(QuinFun) 
		{
			case "BF": nodes = BF(nodes,expandedNodes);	break;
			case "DF": nodes = DF(nodes,expandedNodes); break;
			case "ID":	break;
			case "UC":	break;
			case "GRi": break;
			case "ASi": break;
			default: 	break;
		}
		
		
		
		
	}
		
}

public Queue<Search_Node> BF(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	
	for(int i=0; i<expandedNodes.size();i++) {
		q.add(expandedNodes.get(i));	
	}
	return q;
	
}

public Queue<Search_Node> DF(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
{
	
	Queue<Search_Node> temp = new LinkedList<Search_Node>();
	
	for(int i=0; i<expandedNodes.size();i++) {
		temp.add(expandedNodes.get(i));	
	}
	
	for(int i = 0; i <q.size();i++)
	{
		temp.add(q.poll());
	}
	return temp;
	
}

//public Queue<Search_Node> UC(Queue<Search_Node> q, ArrayList<Search_Node> expandedNodes)
//{
	
//}





}