
public abstract class Problem {
	byte initState;
	static byte [] stateSpace;
	static Operator [] operators;        
	
public abstract int pathCost();
}
