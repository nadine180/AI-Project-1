
public abstract class Generic_Search extends Problem {
	String grid,strategy;
	boolean visualize;
	public Generic_Search(Problem p, String strategy) {
		
	}

	
public abstract boolean goalTest(State state);
public abstract int pathCost();
public abstract Search_Node transitionFun();
	
}
