import java.io.IOException;
import java.util.StringTokenizer;

public class Main {
	
	public static String solve(String grid, String strategy, boolean visualize) {
		Operator [] operators = {Operator.COLLECT,Operator.KILL,Operator.SNAP,Operator.UP,Operator.DOWN,Operator.LEFT,Operator.RIGHT};

		
		StringTokenizer st = new StringTokenizer(grid,";");
		String gridDime = st.nextToken();
		String ironman= st.nextToken();
		String thanos= st.nextToken();
		String stones= st.nextToken();
		String warriors= st.nextToken();
		String g= gridDime+";"+ironman+";"+thanos+";"+"s,"+stones+";"+"w,"+warriors;
		
		EndGameState initState = new EndGameState("0;"+g);
		End_Game endGame = new End_Game(initState,operators );
		
		if(strategy.equals("ID")){
			return endGame.ID(endGame);
		}
		return endGame.General_Search(endGame, strategy);
	 
	}
	public static void main (String[] args) throws IOException {
		/*BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Grid:");
		String grid = br.readLine();
		System.out.println("Enter Strategy:");
		String strategy = br.readLine();
		System.out.println("Visualize?");
		boolean visualization = new Boolean(br.readLine());
		*/
		
		
	
		String grid = "5,5;1,2;3,1;0,2,1,1,2,1,2,2,4,0,4,1;0,3,3,0,3,2,3,4,4,3";
		//String grid = "15,15;12,13;5,7;7,0,9,14,14,8,5,8,8,9,8,4;6,6,4,3,10,2,7,4,3,11";
		String strategy = "UC";
		boolean visualization = false;
		
		solve(grid,strategy,visualization);
		
	}

}
