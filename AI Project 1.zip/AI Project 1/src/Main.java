import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Main {
	
	public static String solve(String grid, String strategy, boolean visualize) {
		Operator [] operators = {Operator.COLLECT,Operator.KILL,Operator.SNAP,Operator.UP,Operator.DOWN,Operator.LEFT,Operator.RIGHT};

		
		StringTokenizer st = new StringTokenizer(grid,";");
		String gridDime = st.nextToken();
		String ironman= st.nextToken();
		String thanos= st.nextToken();
		String stones= st.nextToken();
		String warriors= st.nextToken();
		String g= gridDime+";"+ironman+";"+thanos+";"+"s,"+stones+";"+"w,"+warriors;
		
		EndGameState initState = new EndGameState("0;"+g);
		End_Game endGame = new End_Game(initState,operators );
		
		return endGame.General_Search(endGame, strategy);
	 
	}
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Grid:");
		String grid = br.readLine();
		System.out.println("Enter Strategy:");
		String strategy = br.readLine();
		System.out.println("Visualize?");
		boolean visualization = new Boolean(br.readLine());
		
		solve(grid,strategy,visualization);
		
	}

}
