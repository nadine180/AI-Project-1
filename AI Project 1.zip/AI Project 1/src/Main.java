import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Main {
	
	public static String solve(String grid, String strategy, boolean visualize) {
		Operator [] operators = {Operator.LEFT,Operator.RIGHT,Operator.UP,Operator.DOWN,Operator.COLLECT,Operator.KILL,Operator.SNAP};

		
		StringTokenizer st = new StringTokenizer(grid,";");
		String gridDime = st.nextToken();
		String ironman= st.nextToken();
		String thanos= st.nextToken();
		String stones= st.nextToken();
		String warriors= st.nextToken();
		String g= gridDime+";"+ironman+";"+thanos+";"+"s,"+stones+";"+"w,"+warriors;
		//System.out.println(g);
		
		
		//Grid
		//StringTokenizer stt = new StringTokenizer(s,",");
		/*
		//int m = Integer.parseInt(stt.nextToken());
		//int n = Integer.parseInt(stt.nextToken());
		String g= s;
		//Point g = new Point(m,n);
		
		
		//ironman
		//stt = new StringTokenizer(st.nextToken(),",");
		//int ix = Integer.parseInt(stt.nextToken());
		//int iy = Integer.parseInt(stt.nextToken());
		//Point ironman = new Point(ix,iy);
		String ironman= st.nextToken();
		
		//thanos
		//stt = new StringTokenizer(st.nextToken(),",");
		//int tx = Integer.parseInt(stt.nextToken());
		//int ty = Integer.parseInt(stt.nextToken());
		String thanos= st.nextToken();
		//Point thanos = new Point(tx,ty);
		//stones
		//stt = new StringTokenizer(st.nextToken(),",");
		String stones= st.nextToken();
		ArrayList<Point> stones = new ArrayList<Point>();
		
		while(stt.hasMoreTokens())
		{
			int x = Integer.parseInt(stt.nextToken());
			int y= Integer.parseInt(stt.nextToken());
			
			Point pt = new Point(x,y);
			stones.add(pt);
		}*/
		
		//stt = new StringTokenizer(st.nextToken(),",");
		//ArrayList<Point> warriors = new ArrayList<Point>();
		//String warriors= st.nextToken();
		/*while(stt.hasMoreTokens())
		{
			int x = Integer.parseInt(stt.nextToken());
			int y= Integer.parseInt(stt.nextToken());
			
			Point pt = new Point(x,y);
			warriors.add(pt);
		}
	*/
		
		EndGameState initState = new EndGameState("0;"+g);
		End_Game endGame = new End_Game(initState,operators );
		
		return endGame.General_Search(endGame, strategy);
	 
	}
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Grid:");
		String grid = br.readLine();
		System.out.println("Enter Strategy:");
		String strategy = br.readLine();
		System.out.println("Visualize?");
		boolean visualization = new Boolean(br.readLine());
		
		solve(grid,strategy,visualization);
		
	}

}
