import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	
	public static String solve(String grid, String strategy, boolean visualize) {
		Operator [] operators = {Operator.COLLECT,Operator.KILL,Operator.SNAP,Operator.UP,Operator.DOWN,Operator.LEFT,Operator.RIGHT};

		
		StringTokenizer st = new StringTokenizer(grid,";");
		String gridDime = st.nextToken();
		String ironman= st.nextToken();
		String thanos= st.nextToken();
		String stones= st.nextToken();
		String warriors= st.nextToken();
		String g= gridDime+";"+ironman+";"+thanos+";"+"s,"+stones+";"+"w,"+warriors;
		
		EndGameState initState = new EndGameState("0;"+g);
		End_Game endGame = new End_Game(initState,operators );
		
		if(strategy.equals("ID")){
			return endGame.ID(endGame);
		}
		return endGame.General_Search(endGame, strategy);
	 
	}
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		/*System.out.println("Enter Grid:");
		String grid = br.readLine();
		System.out.println("Enter Strategy:");
		String strategy = br.readLine();
		System.out.println("Visualize?");
		boolean visualization = new Boolean(br.readLine());
		*/
		
		String grid = "5,5;1,2;3,1;0,2,1,1,2,1,2,2,4,0,4,1;0,3,3,0,3,2,3,4,4,3";
		String grid1 = "7,7;5,4;0,1;5,0,5,6,3,1,4,3,1,2,6,3;2,5,2,6,1,0,5,5,6,5";
		String strategy = "AS2";
		boolean visualization = false;
		
		solve(grid,strategy,visualization);
		
	}

}
