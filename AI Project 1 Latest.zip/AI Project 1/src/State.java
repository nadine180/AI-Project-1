
public class State {
	String state;
	
	public State(String state){
		this.state= state;
	}

}
